#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import os
import sys


def main():
    """Run administrative tasks."""
    # Detectar el entorno (producción vs desarrollo) dinámicamente usando DEBUG
    try:
        import importlib.util
        from django_settings_env import Env
        env = Env()
        is_debug = env.bool('DEBUG', default=True)
    except Exception:
        is_debug = True

    if not is_debug:
        os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings.production')
    else:
        os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings.local')

    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()
