from django.contrib import admin
from django.urls import path,include,re_path
from django.conf import settings
from django.conf.urls.static import static
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi


schema_view = get_schema_view(
    openapi.Info(
        title="Documentación de API",
        default_version='v0.1',
        description="Documentación privada de API de gestion de pedidos",
        terms_of_service="https://www.google.com/policies/terms/",
        contact=openapi.Contact(email="aragozaca@gmail.com"),
        license=openapi.License(name="BSD License"),
    ),
    public=True,
    permission_classes=(permissions.AllowAny,),
)


urlpatterns = [
    re_path(r'^swagger(?P<format>\.json|\.yaml)$', schema_view.without_ui(cache_timeout=0), name='schema-json'),
    path('swagger/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    path('redoc/', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),
    
    path('admin/', admin.site.urls),
    path('api/products/', include('apps.product.api.routers')),
    path('api/projects/', include('apps.project.api.routers')),
    path('api/gallery/', include('apps.gallery.api.routers')),
    path('api/user/', include('apps.user.api.routers')),
    path('api/', include('apps.orders.api.routers')),

    path('api/', include('apps.payment.api.routers')),
    path('api/', include('apps.shipment.api.routers')),
    path('api/', include('apps.notification.api.routers')),
    path('api/', include('apps.invoice.api.routers')),
]






# Configuración para servir archivos multimedia en desarrollo
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

