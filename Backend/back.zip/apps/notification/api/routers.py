from rest_framework.routers import DefaultRouter
from apps.notification.api.views import NotificationViewSet

router = DefaultRouter()
router.register(r'notifications', NotificationViewSet, basename='notifications')

urlpatterns = router.urls
